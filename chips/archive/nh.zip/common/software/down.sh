#!/bin/sh

squish -l modules2.fr
squish -l rtxcross.fr
squish -l struct.fr
squish -l timers2.fr
squish -l far2.fr

echo ": mask 1 swap lshift 1- ;"
squish hw.fr
squish time.fr
squish host-io.fr
