#!/bin/sh

echo "d# 12000 constant #i2c-clocks"
echo "3 constant #i2c-slots"
echo "1 2* constant #lvps-i2c"

squish -l rtxcross.fr
squish -l modules2.fr
squish extend-mess.fr hw.fr
squish i2c.fr i2c-user.fr power.fr
