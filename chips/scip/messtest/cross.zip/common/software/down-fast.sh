#!/bin/sh

squish -l rtxcross.fr
squish -l modules2.fr
squish -l far2.fr
squish -l fardump.fr
squish $FTROOT/rtx/lib/time.fr
#squish extend-mess.fr
squish fast16.fr packbits.fr
squish foo.fr
